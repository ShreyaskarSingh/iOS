//
//  ViewController.swift
//  Help In Hand 2
//
//  Created by Shreyaskar Singh on 4/1/19.
//  Copyright © 2019 Shreyaskar Singh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var Image: UIImageView!
    
    @IBOutlet weak var name: UILabel!
    
    @IBAction func call(_ sender: Any) {
        if let url = URL(string: "tel://\(123456789)"),
            UIApplication.shared.canOpenURL(url) {
            
            UIApplication.shared.open(url, options: [:], completionHandler:nil)
        }
    }
    var valueForLabel1 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        name.text! = valueForLabel1
        Image.image = UIImage(named: "\(valueForLabel1)")
    }


}

